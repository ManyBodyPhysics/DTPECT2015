This IPython notebook mbpt.ipynb does not require any additional
programs.
