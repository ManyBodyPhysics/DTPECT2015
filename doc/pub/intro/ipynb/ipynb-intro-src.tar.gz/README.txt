This IPython notebook intro.ipynb does not require any additional
programs.
